<div class='platform-icons'>
    <img src="images\platforms\spotify.svg" class="platform-icon">

    <img src="images\platforms\youtube.png" class="platform-icon">
    <img src="images\platforms\soundcloud.png" class="platform-icon">
    
</div><?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/user/components/sponsors.blade.php ENDPATH**/ ?>