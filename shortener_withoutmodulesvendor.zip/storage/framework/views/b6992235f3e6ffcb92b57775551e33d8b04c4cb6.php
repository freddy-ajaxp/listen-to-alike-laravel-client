<?php if(isset($emptyLayout) && $emptyLayout): ?>
<div class="form-group">
    <input type="hidden" name="id_platforms[]" value="" />
    <div class="form-row">
        <div class="col-sm-2">
            <div class="">
                <label for="form-control form-control"> Platform
                    <?php
                    ?>
                </label>

                
                <select name="data_platform[]" class="custom-select ">
                
                    <option disabled="" selected="" value="null">Platform </option>
                    <?php $__currentLoopData = $platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($platform['platform_name']); ?>"><?php echo e($platform['platform_name']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="col-sm-7">
            <div class="form-group">
                <div class="">
                    <div>
                        <label>URL</label>
                    </div>
                    <input type="text" id="platform0" name="data_url_platform[]" class="form-control form-control" placeholder="Enter Platform link">
                </div>
            </div>
        </div>


        <div class="col-sm-2">
            <div class="">
                <div>
                    <label> Button Text</label>
                </div>
                <select name="data_text[]" class="custom-select">
                    <?php $__currentLoopData = $texts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($text['text']); ?>"><?php echo e($text['text']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>


        <div class="col-sm-1">
            <div class="music-link__reposition">
                <button type="button" name="remove" id="" class="btn btn-danger remove">X</button>
            </div>
        </div>
    </div>
</div>

<?php else: ?>
<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="form-group">
    <input type="hidden" name="id_platforms[]" value="<?php echo e($dt['id']); ?>" />
    <div class="form-row">

        <div class="col-sm-2">
            <div class="">
                <label for="form-control form-control"> Platform
                    <?php
                    ?>
                </label>
                <select name="data_platform[]" class="custom-select">
                    <?php $__currentLoopData = $platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option 
                    <?php
                        if ($platform['platform_name'] === $dt['jenis_platform']) echo 'selected="selected"';
                    ?>  
                    value="<?php echo e($platform['platform_name']); ?>"><?php echo e($platform['platform_name']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="col-sm-7">
            <div class="form-group">
                <div class="">
                    <div>
                        <label>URL</label>
                    </div>
                    <input type="text" name="data_url_platform[]" class="form-control form-control" placeholder="URL dari platform" value="<?php echo e($dt['url_platform']); ?>" />
                </div>
            </div>
        </div>


        <div class="col-sm-2">
            <div class="">
                <div>
                    <label> Button Text</label>
                </div>
                <select name="data_text[]" class="custom-select">
                    <?php $__currentLoopData = $texts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option 
                    <?php
                        if ($text['text'] ===  $dt['text']) echo 'selected="selected"';
                    ?>  
                    value="<?php echo e($text['text']); ?>"><?php echo e($text['text']); ?>  </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>


        <div class="col-sm-1">
            <div class="music-link__reposition">
            <div class="icon-inner"title="delete"><button type="button" name="remove" id="" class="btn btn-danger btn-sm remove">X</button></div>
            
            
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/user/partials/select-platform.blade.php ENDPATH**/ ?>