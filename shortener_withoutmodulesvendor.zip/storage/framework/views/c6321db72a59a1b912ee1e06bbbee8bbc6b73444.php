
<?php if(session()->has('admin')): ?>
<div class="navbar navbar-expand-md container" style='justify-content:space-between'>
    <a class="navbar-brand float-left" href="/">
        <span class='ml-0'><img style="max-height:70px" src='<?php echo e(asset('images/icons/headphone.svg')); ?>'></span>
    </a>
    <div class="navbar-nav" style='flex-direction: row;align-items: center'>
        
        <a class="btn btn-danger btn-sm " id="btn-dashboard" style='color:#fff' href="/dashboard">Dashboard</a>
        &nbsp;
        <?php if(session('admin')==0): ?>
        <div class="dropdown show">
            <a class="btn btn-secondary btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('heroicon-o-cog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['style' => 'height:20px']); ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                Settings
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                <a class="dropdown-item" href="user/profile">Profile </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="/user/logout">
                    Logout</span>
                </a>
            </div>
        </div>
        
        <?php elseif(session('admin')==1): ?>
        <a class="btn btn-default btn-sm " id="btn-dashboard" style='color:white' href="/dashboard">Logout</a>
        <?php endif; ?>
    </div>

</div>
<?php else: ?>
<div class="navbar navbar-expand-md container" style='justify-content:space-between'>
    <a class="navbar-brand float-left" href="/">
        <span class='ml-0'><img style="max-height:70px" src='<?php echo e(asset('images/icons/headphone.svg')); ?>'></span>
    </a>
    <div class="navbar-nav" style='flex-direction: row;align-items: center'>
        <a class="btn btn-danger btn-sm " style='color:#fff' href="/login">Login</a>
        <a class="nav-item-btn nav-item btn btn-sm btn-red text-white" href=/register>
            Register<span id="nav-item__free"></span>
        </a>
    </div>

</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/user/components/navbar.blade.php ENDPATH**/ ?>