


<?php $__env->startSection('title', __('Detail Link')); ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components/user/components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components/user/components/modal-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components/user/components/alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="section-1-bg" style="background:linear-gradient( to right,rgb(6, 34, 62),rgba(5, 32, 68, 0.66));">
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="container-fluid">
                                <div class="row ">
                                    <div class="col-sm-6">
                                        <h3>Detail Link <a href="<?php echo e(url('preview/' .$data['link'][0]['short_link'])); ?>" target="__blank"><?php echo e($data['link'][0]['short_link']); ?></a></h3>
                                        <?php if(session()->has('admin')): ?>
                                        <a href="<?php echo e(url('/admin')); ?>" >< kembali</a>
                                        <?php else: ?>
                                        <a href="<?php echo e(url('/dashboard')); ?>" >< kembali</a>
                                        <?php endif; ?>
                                        
                                    </div>
                                </div>
                            </div><!-- /.container-fluid -->
                        </div>

                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="content">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="card card-primary card-outline">
                                            <div class="card-body box-profile"> 

                                                <h3 class="profile-username text-center"><?php echo e($data['link'][0]['title']); ?></h3>

                                                <ul class="list-group list-group-unbordered mb-3">
                                                    <li class="list-group-item">
                                                        <b>Visit count</b> <a class="float-right"><?php echo e($data['link'][0]['count']); ?></a>
                                                        <img src="<?php echo e(asset('images/icons/question-circle.svg')); ?>" style="margin-bottom: 10px;" data-toggle="tooltip" title="Jumlah kunjungan ke kedalam Link Anda"/>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="col-lg-8 col-md-6">
                                    <div class="card">
                                            <div class="card-header border-0">
                                                <h3 class="card-title">Clickthroughs 
                                                <img src="<?php echo e(asset('images/icons/question-circle.svg')); ?>"  style="margin-bottom: 10px;" data-toggle="tooltip" title="Jumlah klik pada tiap platform"/> 
                                                </h3>
                                                <div class="card-tools">
                                                    <a href="#" class="btn btn-tool btn-sm">
                                                        <i class="fas fa-download"></i>
                                                    </a>
                                                    <a href="#" class="btn btn-tool btn-sm">
                                                        <i class="fas fa-bars"></i>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="card-body table-responsive p-0" style="max-height:250px; overflow:scroll;">
                                                <table class="table table-striped table-valign-middle">
                                                    <thead>
                                                        <tr>
                                                            <th>Platform</th>
                                                            <th>Visits</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $data['platform']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            
                                                            <td>
                                                                <a target="__blank" href="<?php echo e($platform->url_platform); ?>">
                                                                    <?php echo e($platform->url_platform); ?>

                                                                </a>
                                                            </td>
                                                            <td>
                                                                <?php echo e($platform->count); ?>

                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <div class="card-header border-0">
                                                <h3 class="card-title">Referring Domains
                                                <img src="<?php echo e(asset('images/icons/question-circle.svg')); ?>"  style="margin-bottom: 10px;" data-toggle="tooltip" title="Asal domain seseorang yang mengunjungi Link Anda"/>
                                                </h3>
                                                <div class="card-tools">
                                                    <a href="#" class="btn btn-tool btn-sm">
                                                        <i class="fas fa-download"></i>
                                                    </a>
                                                    <a href="#" class="btn btn-tool btn-sm">
                                                        <i class="fas fa-bars"></i>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="card-body table-responsive p-0" style="max-height:250px; overflow:scroll;">
                                                <table class="table table-striped table-valign-middle">
                                                    <thead>
                                                        <tr>
                                                            <th>Referer</th>
                                                            <th>Count</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php $__currentLoopData = $data['referer']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $referer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            
                                                            <td>
                                                                    <?php echo e($referer->referer); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($referer->count); ?>

                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
</section>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('stylesheets'); ?>


<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/navbar.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/adminlte.min.css')); ?>">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/music-links.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/form-validation.css')); ?>">
<?php $__env->stopPush(); ?>


<?php $__env->startPush('javascript'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.validate.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/adminlte.min.js')); ?>"></script>
<script type="text/javascript" src=" <?php echo e(asset('assets/js/chart/Chart.js')); ?>">
    <script type="text/javascript" src="<?php echo e(asset('assets/js/spinner.js')); ?>">

</script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/alert.js')); ?>"></script>
<script>
    $(function() {
        'use strict'

        var ticksStyle = {
            fontColor: '#495057'
            , fontStyle: 'bold'
        }

        var mode = 'index'
        var intersect = true



        var $visitorsChart = $('#visitors-chart')
        var visitorsChart = new Chart($visitorsChart, {
            data: {
                labels:['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31']
                , datasets: [{
                    type: 'line'
                    , data: [100, 120, 170, 167, 180, 177, 160]
                    , backgroundColor: 'transparent'
                    , borderColor: '#007bff'
                    , pointBorderColor: '#007bff'
                    , pointBackgroundColor: '#007bff'
                    , fill: false
                    // pointHoverBackgroundColor: '#007bff',
                    // pointHoverBorderColor    : '#007bff'
                }]
            }
            , options: {
                maintainAspectRatio: false
                , tooltips: {
                    mode: mode
                    , intersect: intersect
                }
                , hover: {
                    mode: mode
                    , intersect: intersect
                }
                , legend: {
                    display: false
                }
                , scales: {
                    yAxes: [{
                        // display: false,
                        gridLines: {
                            display: true
                            , lineWidth: '4px'
                            , color: 'rgba(0, 0, 0, .2)'
                            , zeroLineColor: 'transparent'
                        }
                        , ticks: $.extend({
                            beginAtZero: true
                            , suggestedMax: 200
                        }, ticksStyle)
                    }]
                    , xAxes: [{
                        display: true
                        , gridLines: {
                            display: false
                        }
                        , ticks: ticksStyle
                    }]
                }
            }
        })
    })

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('components.user.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/user/view/detail-link.blade.php ENDPATH**/ ?>