<div class='platform-icons'>
    <img src="images\platforms\spotify.svg" class="platform-icon">

    <img src="images\platforms\spotify.svg" class="platform-icon">
    <img src="images\platforms\spotify.svg" class="platform-icon">
    <img src="images\platforms\spotify.svg" class="platform-icon">
    <img src="images\platforms\spotify.svg" class="platform-icon">
    <!-- <img src="images\platforms\apple-music.svg" class="platform-icon">
    <img src="images\platforms\tidal.svg" class="platform-icon" style='opacity:0.6'>
    <img src="images\platforms\pandora.svg" class="platform-icon">
    <img src="images\platforms\google-play.svg" class="platform-icon platform-icon--google-play"> -->
</div>