<!-- modal -->
<div class="modal bd-example-modal-xl" id="modals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="dynamic-modal-container">
    </div>
</div>
</div>
</div>
<!-- modal end -->
