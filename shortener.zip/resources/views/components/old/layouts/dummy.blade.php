@extends('layouts.default')

@section('title', __('Create Role'))

@section('content')

@endsection
