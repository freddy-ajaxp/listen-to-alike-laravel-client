<!-- modal delete -->
    <div class="modal" id="modal-delete" role="dialog">
        <form id="form-delete" name="form-delete" class="form-horizontal" >
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Konfirmasi Hapus Data</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>konfirmasi hapus data:</p>
                        <input type="hidden" id="id_delete" />
                        <p name="confirm-delete-name"> asdasd</p>
                        <p>Lanjutkan?</p>

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-danger">Hapus</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- modal delete end -->