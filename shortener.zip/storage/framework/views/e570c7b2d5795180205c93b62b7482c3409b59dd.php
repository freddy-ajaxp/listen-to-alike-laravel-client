    <form id="form-report-info" name="form-ban-link" class="form-horizontal">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Detail Laporan/Aduan </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <div style="max-height: 500px; overflow-y: auto;">
                    <table class="table table-striped projects" >
                        <thead>
                            <tr>
                                <th>
                                    #
                                </th>
                                <th>
                                    Jenis Laporan
                                </th>
                                <th>
                                    Jumlah
                                </th>
                            </tr>
                        </thead>
                        <tbody >
                            <?php $__currentLoopData = $reportsInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($key+1); ?>

                                </td>
                                <td>
                                    <?php echo e($report['reason']); ?>

                                </td>
                                <td>
                                    <?php echo e($report['jumlah']); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>    
                    </div>
                    <div class="table-responsive ">
                        <table id="example2" class="table table-bordered table-striped table-hover users-table ">
                            <thead>
                                <tr>
                                    <th>Catatan Pengunjung</th>
                                </tr>
                            </thead>
                            <tbody style="height: 10px; overflow-y: scroll"></tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
<?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/admin/partials/modal-report-info.blade.php ENDPATH**/ ?>