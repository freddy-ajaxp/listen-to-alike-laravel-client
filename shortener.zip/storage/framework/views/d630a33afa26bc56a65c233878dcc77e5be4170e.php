
<?php $__env->startSection('title', __('Login')); ?>
<?php $__env->startPush('stylesheets'); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

<h1>TEST PAGE</h1>

<body>
 
	<div class="container">
		<div class="card mt-5">
			<div class="card-body">
				<h3 class="text-center"><a href="https://www.malasngoding.com">www.malasngoding.com</a></h3>
				<h5 class="text-center my-4">Eloquent One To One Relationship</h5>
				<table class="table table-bordered table-striped">
					<thead>
						<tr>
							<th>url_platform</th>
							<th>logo_image_path</th>
                            <th>text</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($p->url_platform); ?></td>
							<td><?php echo e($p->list_platform->logo_image_path); ?></td>
                            <td><?php echo e($p->List_text->text); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
 
</body>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('javascript'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('components.user.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/user/view/test.blade.php ENDPATH**/ ?>