<form id="form-delete-logo" name="form-delete-logo" class="form-horizontal" >
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Konfirmasi Hapus Logo</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Konfirmasi Menghapus Logo?<p name="confirm-delete-name"> </p>
                    <input type="hidden" id="id_delete_logo" />
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-danger">Hapus</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form><?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/admin/partials/modal-delete-platform.blade.php ENDPATH**/ ?>