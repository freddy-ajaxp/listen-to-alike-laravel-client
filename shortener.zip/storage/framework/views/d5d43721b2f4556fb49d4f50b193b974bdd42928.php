<div id="overlay-alert" style="display:none" onclick='toggleAlert(false)'>
    <div id="text">
        <div class="d-flex flex-column align-items-center justify-content-center">
            <div class="row">
                <div class="alert alert-danger alert-dismissible fade show" role="alert" id="alert-error">
                    <strong>Alert!</strong> Something Happenned.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/user/components/alert.blade.php ENDPATH**/ ?>