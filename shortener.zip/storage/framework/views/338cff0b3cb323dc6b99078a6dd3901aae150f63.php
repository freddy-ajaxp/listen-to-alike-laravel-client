<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->yieldPushContent('stylesheets'); ?>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/spinner.css')); ?>">
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        
        <?php echo $__env->make('components/admin/components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /.navbar -->
        <?php echo $__env->make('components/admin/components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Content Wrapper. Contains page content -->
        
        <?php echo $__env->make('components/admin/components/spinner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('components/admin/components/modal-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <footer class="main-footer">
            <div class="float-right d-none d-sm-block">
                <b>Version</b> 1.0.0 
            </div>
            <strong>Copyright &copy; 2019 <a href="#">bonaxcrimo@gmail.com</a>.</strong> All rights reserved.
        </footer>
    </div>
</body>
</html>


<?php echo $__env->yieldPushContent('javascript'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/js/spinner.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script><?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/admin/layouts/default.blade.php ENDPATH**/ ?>