<form id="form-delete-text" name="form-delete-text" class="form-horizontal" >
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Konfirmasi Hapus Text</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    Konfirmasi Menghapus Text? <p name="confirm-delete-name"> </p>
                    <input type="hidden" id="id_delete_text" value="<?php echo e($data->id); ?>"/>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-danger">Hapus</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form><?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/admin/partials/modal-delete-text.blade.php ENDPATH**/ ?>