<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">
 
    <!-- CSS -->
    <?php echo $__env->yieldPushContent('stylesheets'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/spinner.css')); ?>">

</head>

<body>
    <div class="App">
        <div class="section section-1" style="background-image: url('images/background.jpg');
                background-size: cover;
              background-position: center center;
              background-attachment: fixed;" `>
            <div class="section-1-bg" style="background:linear-gradient( to right,rgb(6, 34, 62),rgba(5, 32, 68, 1));">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
</body>
<?php echo $__env->make('components.user.components.spinner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>

<script type="text/javascript" src="<?php echo e(asset('assets/js/spinner.js')); ?>"></script>
 <?php echo $__env->yieldPushContent('javascript'); ?>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/user/layouts/default.blade.php ENDPATH**/ ?>