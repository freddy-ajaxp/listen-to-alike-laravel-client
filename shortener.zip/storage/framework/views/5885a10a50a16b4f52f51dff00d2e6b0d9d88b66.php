<div id="overlay" style="display:none" onclick='toggleSpinner(false)'>
    <div id="text">
        <div class="d-flex flex-column align-items-center justify-content-center">
            <div class="row">
                <div class="spinner-border" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
            <div class="row" id="spinner-text">
                <strong>Processing Your Request</strong>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/user/components/spinner.blade.php ENDPATH**/ ?>