<div style="text-align: right;position: fixed;z-index:9999;bottom: 0;width: auto;right: 1%;cursor: pointer;line-height: 3;display:block !important;">
    <a title="Report Link" target="_blank" href="" data-toggle="modal" data-target="#modals">

        <img style="max-height: 20px;" src="<?php echo e(asset('images/icons/warning.png')); ?>" alt="report">
        report
        
    </a>
</div>

<div class="modal fade" id="modals" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index:9999">
    <form id="form-report">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Report This Link</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <label for="message-text" class="col-form-label">Please tell us the reason:</label>

    






                    <?php $__currentLoopData = $reasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $reason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <div class="form-check">
                            <input name="reasons[]" class="form-check-input" type="checkbox" value="<?php echo e($reason->text); ?>" data-id="<?php echo e($reason->id); ?>" id="reason-<?php echo e($reason->id); ?>">
                            <label class="form-check-label" for="reason-<?php echo e($reason->id); ?>">
                                <?php echo e($reason->text); ?>

                            </label>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <div class="form-check">
                            <label for="message-text" class="col-form-label">More:</label>
                            <textarea class="form-control" id="reason" style="resize: none; color: inherit;"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/admin/components/report-button.blade.php ENDPATH**/ ?>