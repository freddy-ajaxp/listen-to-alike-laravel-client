<!-- modal delete form-->
<div class="modal" id="modal-delete" role="dialog">
    
</div>
<!-- modal delete end -->

<!-- modal delete user-->
<div class="modal" id="modal-delete-user" role="dialog">
    
</div>
<!-- modal delete end -->

<!-- modal reset -->
    <div class="modal" id="modal-reset" role="dialog">
        
    </div>
    <!-- modal  end -->


<!-- modal delete svg logo  -->
<div class="modal" id="modal-delete-logo" role="dialog">
    
</div>
<!-- modal delete svg logo end --><?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/admin/components/modals.blade.php ENDPATH**/ ?>