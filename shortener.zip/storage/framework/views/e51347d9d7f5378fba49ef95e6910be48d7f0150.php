<div class="header" style="text-align:center">
    <h1 style='color:#a1b4ca;font-size:2.6em'>Let Your Music <b style='font-weight:500;color:#fff'>Be Heard.</b> </h1>
    <h2 style='color: #c1d8f0;font-weight:300' class='mb-1'>Beritahu dunia tentang karya mu. <b>musik, podcasts dan
            pertunjukkan</b>.</h2>       
</div>
<?php /**PATH C:\xampp\htdocs\shortener\resources\views/components/user/components/header.blade.php ENDPATH**/ ?>